<?php
session_start();
if (!isset($_SESSION['user_id'])) {
header('Location:https://marmole7.uwmsois.com/infost440/assignments/finalproject/login.php');
}
?>

<?php
include('header.php');
include('mysqli_connect.php');
?>

<?php
    $user_id = mysqli_real_escape_string($dbc, trim($_SESSION['user_id']));
    $blogpost_id = mysqli_real_escape_string($dbc, trim($_GET['blogpost_id']));
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $comment_body = mysqli_real_escape_string($dbc, trim($_POST['comment']));
    
    $query = "INSERT INTO comments (comment_id,user_id,blogpost_id,comment_body,comment_timestamp) VALUES ('','$user_id','$blogpost_id','$comment_body',NOW())";

    $result = mysqli_query($dbc, $query);

    if ($result){
        echo "<p>New Comment is added!!</p>";
        echo "<p>comment: $comment_body</p>";
    } else {
        echo "THERE IS AN ERROR" . mysqli_error($dbc);
    }
}
?>
<form action="newcomment.php?blogpost_id=<?php echo $blogpost_id;?>" method="POST">
<fieldset>
    <legend> Please Enter New Guetbook Entry</legend>
    
    Please Enter New Comments<br>
    <textarea name="comment" cols="40" rows="20"><?php if (isset($comment_body)) {echo $comment_body;}?></textarea><br>    
    <input type="submit" value="Submit" />
</fieldset>
</form>
<?php include('footer.php');?>