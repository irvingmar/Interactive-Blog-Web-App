<?php
session_start(); // Start the session.
if (isset($_SESSION['user_id'])) {
	include ('header.php');
	echo 'You are logged in!'; 		
} else { 
	header('Location: http://marmole7.uwmsois.com/Infost440/finalproject/login.php');
}
?>