<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: https://marmole7.uwmsois.com/infost440/assignments/finalproject/login.php');
}

// Only admin can add a new blogpost
if ($_SESSION['user_id'] != 3) {
    header('Location: http://marmole7.uwmsois.com/infost440/assignments/finalproject/login.php');
    exit();
}

include('header.php');
include('mysqli_connect.php');

//$page_title = 'Add New Blogpost';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $blogpost_title = mysqli_real_escape_string($dbc, trim($_POST['blogpost_title']));
    $blogpost_body = mysqli_real_escape_string($dbc, trim($_POST['blogpost_body']));
    
    $query = "INSERT INTO blogposts (blogpost_title, blogpost_body, user_id, blogpost_timestamp) VALUES ('$blogpost_title', '$blogpost_body', '{$_SESSION['user_id']}', NOW())";
    
    $result = mysqli_query($dbc, $query);

    if ($result){
        echo "<p>New Blogpost is added!!</p>";
        //echo "<p>Title: $blogpost_title</p>";
        //echo "<p>Body: $blogpost_body</p>";
    } else {
        echo "THERE IS AN ERROR" . mysqli_error($dbc);
    }
}
?>
<form action="newblogpost.php" method="POST">
    <fieldset>
        <legend> Add New Blogpost </legend>
        Title: <br>
        <input type="text" name="blogpost_title" value="<?php if (isset($blogpost_title)) {echo $blogpost_title;}?>"><br>
        Body: <br>
        <textarea name="blogpost_body" cols="40" rows="20"><?php if (isset($blogpost_body)) {echo $blogpost_body;}?></textarea><br>
        <input type="submit" value="Submit" />
    </fieldset>
</form>
<?php include('footer.php');?>