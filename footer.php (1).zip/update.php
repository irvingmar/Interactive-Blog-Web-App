<?php
include('header.php');
include('mysqli_connect.php');


    


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$guestbook_id = $_POST['guestbook_id'];
$comments = $_POST['comment'];
//echo $fname . $lname . $comment;

$query = "UPDATE `guestbook` SET comments = '$comments' WHERE guestbook_id = $guestbook_id";

$result = mysqli_query($dbc, $query);

 if ($result){
     echo "IT WORKED <br>";
     echo "<p>guestbook: $guestbook_id</p>";
     echo "<p>coments: $comments</p>";
} else {
echo "THERE IS AN ERROR" . mysqli_error($dbc); }
}
?>

<form action = "update.php" method = "POST">
<fieldset> 
    <legend> Please Enter A New Guestbook Entry</legend>
    
   Guestbook ID:</br>
  <input name ="guestbook_id" type="text" value="<?php if(isset($guestbook_id)){ echo $guestbook_id; } ?>"
    
    Please Enter New Comments:
    </br>
    <textarea name="comment" cols="40" rows="20"><?php if (isset($comments)) {echo $comments;}?></textarea><br>
        <input type="submit" value="Submit">
</fieldset>
</form>
<?php include('footer.php');?>