<?php

//This includes the header and mysqldatabase.
$page_title = "View Comments";
include('header.php');
include('mysqli_connect.php');

//Get whatever information you need from either GET, SESSION, or POST
$blogid = mysqli_real_escape_string($dbc, trim($_GET['blogpost_id']));

//Your SQL Query
$query = "SELECT * FROM comments WHERE blogpost_id=".$blogid;
$result = mysqli_query($dbc, $query);

//Your loop to display everything
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    echo '<h3>ID</h3>' . $row['comment_id'] . '<br>';
    echo '<h3>Comment</h3>' . $row['comment_body'] . '<br><br>';


}

?>