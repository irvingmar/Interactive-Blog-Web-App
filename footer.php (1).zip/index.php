<?php
// Create Session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blogpost</title>
    <style>
        body {
            background-color: #f5f7fa;
            font-family: Arial, sans-serif;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin: 20px 0;
        }

        .card {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px;
            overflow: hidden;
            width: 5000px;
            border-radius: 20px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background-color: #4a8ab4;
            color: #fff;
            padding: 20px;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }

        .card-header h3 {
            margin: 0;
            font-size: 1.8em;
        }

        .card-header p {
            margin: 0;
            font-size: 1.2em;
        }

        .card-body {
            padding: 20px;
        }

        .card-body p {
            margin: 0;
            font-size: 1.3em;
            line-height: 1.6em;
        }

        h1 {
            text-align: center;
            margin: 20px 0;
            font-size: 3.2em;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Blogpost</h1>
        <div class="card-container">

            <!-- blogpost -->

            <?php
            // If a user name is entered display login message
            if (isset($_SESSION['first_name'])) {
                echo "You currently logged in as {$_SESSION['first_name']}. Welcome to our website!";
            }

            include('mysqli_connect.php');
            include('header.php');

            if (isset($_GET['delete_id'])) {
                // If there is delete_id in URL
                $delete_id = mysqli_real_escape_string($dbc, trim($_GET['delete_id']));
                $delete_query = "DELETE FROM blogposts WHERE blogpost_id = '$delete_id'";
                $delete_results = mysqli_query($dbc, $delete_query);
                // display delete message
                if ($delete_results) {
                } else {
                    $delete_id = "";
                }
            }

            // SORTING SETUP START
            // From Textbook Script 10.5 - #5
            // Determine the sort...
            // Default is by registration date.
            $sort = (isset($_GET['sort'])) ? $_GET['sort'] : 'date';

            // Determine the sorting order:
            switch ($sort) {
                case 'blogpost_id':
                    $order_by = 'blogpost_id DESC';

                    break;

            default:
                $order_by = 'blogpost_id DESC';
                $sort = 'blogpost_id';
                break;
        }

        // Sort buttons
        echo '<div align="center">';
        echo '<strong> Sort By: </strong>';
        echo '<a href="?sort=blogpost_id">Most recent post</a> |';
        echo '</div>';
        // SORTING SETUP END

        // PAGINATION SETUP START
        // From Textbook Script 10.5




//***********************************************
//PAGINATION SETUP START
//From Textbook Script 10.5 - #5
//***********************************************
            
            // Number of records to show per page:
            $display = 5;
            
            // Determine how many pages there are...
            if (isset($_GET['p']) && is_numeric($_GET['p'])) { // Already been determined.
            $pages = $_GET['p'];
            } else { // Need to determine.
            // Count the number of records:
            $q = "SELECT COUNT(blogpost_id) FROM blogposts";
            $r = mysqli_query ($dbc, $q);
            $rowp = mysqli_fetch_array ($r, MYSQLI_NUM);
            $records = $rowp[0];
            // Calculate the number of pages...
            if ($records > $display) { // More than 1 page.
            $pages = ceil ($records/$display);
            } else {
            $pages = 1;
            }
            } // End of p IF.
            
            // Determine where in the database to start returning results...
            if (isset($_GET['s']) && is_numeric($_GET['s'])) {
            $start = $_GET['s'];
            } else {
            $start = 0;
            }
//***********************************************
//PAGINATION SETUP END
//***********************************************
			
			
			
			// Select blogpost table
$query = "SELECT blogposts.blogpost_id, blogposts.blogpost_title, blogposts.blogpost_body, comments.comment_body FROM blogposts LEFT JOIN comments ON blogposts.blogpost_id = comments.blogpost_id ORDER BY $order_by LIMIT $start, $display";
$results = mysqli_query($dbc,$query);

if ($results) {
    while($row = mysqli_fetch_array($results, MYSQLI_ASSOC)){
        ?>
        <div class="card-header">
           <div class="card-header">
               <h2><?php echo $row['blogpost_id']; ?><h2>
               <h3> <?php echo $row['blogpost_title']; ?></h3>
               <p><?php echo $row['blogpost_body']; ?></p>
               <p><?php echo $row['comment_body']; ?></p>
              </div>
             </div>
             <?php
             //New comment 
             if (isset($_SESSION['user_id'])) {
            echo "<a href = 'newcomment.php?blogpost_id=".$row['blogpost_id']. "'>Add Comment</a><br>";
             }
             
             //view comments
            echo "<a href = 'viewcomments.php?blogpost_id=".$row['blogpost_id']. "'>View Comment</a><br>";
             //update button 
             if (isset($_SESSION['user_id']) AND $_SESSION['user_id'] ==3) { 
             echo "<a href = 'update.php?blogpost_id=".$row['blogpost_id']. "'>Update Comment</a><br>";
             }
        
             //delete button 
             if (isset($_SESSION['user_id']) AND $_SESSION['user_id'] ==3) { 
             echo "<a href = 'index.php?delete_id=".$row['blogpost_id']. "'>Delete blogpost</a><br>";
             }
             ?>
             
            

<?php
        
    }
} else { 
    echo "There was an error" . mysqli_error($dbc);
}
?>
</div>

<?php include('footer.php'); ?>

<?php
//***********************************************
//PAGINATION PREVIOUS AND NEXT PAGE BUTTONS/LINKS START
//***********************************************

// Make the links to other pages, if necessary.
if ($pages > 1) {

echo '<br /><p>';
$current_page = ($start/$display) + 1;

// If it's not the first page, make a Previous button:
if ($current_page != 1) {
echo '<a href="?s=' . ($start - $display) . '&p=' . $pages . '&sort=' . $sort . '">Previous</a> ';
}

// Make all the numbered pages:
for ($i = 1; $i <= $pages; $i++) {
if ($i != $current_page) {
echo '<a href="?s=' . (($display * ($i - 1))) . '&p=' . $pages . '&sort=' . $sort . '">' . $i . '</a> ';
} else {
echo $i . ' ';
}
} // End of FOR loop.

// If it's not the last page, make a Next button:
if ($current_page != $pages) {
echo '<a href="?s=' . ($start + $display) . '&p=' . $pages . '&sort=' . $sort . '">Next</a>';
}

echo '</p>'; // Close the paragraph.

} // End of links section.

//***********************************************
//PAGINATION PREVIOUS AND NEXT PAGE BUTTONS/LINKS END
//***********************************************

//header
include('footer.php');
?>

